package com.carter.graduation.design.music.info;

/**
 * Created by carter on 2018/3/13
 */

public class LrcInfo {

    private String lrcStr;
    private int lrcTime;

    public String getLrcStr() {
        return lrcStr;
    }

    public void setLrcStr(String lrcStr) {
        this.lrcStr = lrcStr;
    }

    public int getLrcTime() {
        return lrcTime;
    }

    public void setLrcTime(int lrcTime) {
        this.lrcTime = lrcTime;
    }
}
